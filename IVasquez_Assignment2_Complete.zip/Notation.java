
public class Notation extends java.lang.Object 
{

	public static double evaluatePostfixExpression​(String postfixExpr) throws InvalidNotationFormatException
	{	
		MyStack<Double> stack = new MyStack<Double>(postfixExpr.length());
		
		try 
		{
			
			for (int i = 0; i < postfixExpr.length(); i++) 
			{
				if (postfixExpr.charAt(i) >= '0' && postfixExpr.charAt(i) <= '9')
				{
					stack.push(Double.parseDouble(postfixExpr.charAt(i) + ""));
				}
				else 
				{
					double second = stack.pop();
					double first = stack.pop();
					double outcome = 0;
					
					if(postfixExpr.charAt(i) == '+')
					{
						outcome = first + second;
						stack.push(outcome);
					}
					else if(postfixExpr.charAt(i) == '-')
					{
						outcome = first - second;
						stack.push(outcome);
					}
					else if(postfixExpr.charAt(i) == '*')
					{
						outcome = first * second;
						stack.push(outcome);
					}
					else if(postfixExpr.charAt(i) == '/')
					{
						outcome = first / second;
						stack.push(outcome);
					}			
				}

				
			}

			if (stack.size() > 1)
			{
				throw new InvalidNotationFormatException();
			}

			return stack.pop();
		} 
		
		catch (StackUnderflowException e) 
		{
			System.out.println("An uderflow error");
			throw new InvalidNotationFormatException();
		} 
		
		catch (Exception e) 
		{
			System.out.println("Another type of error");
			e.printStackTrace();
		}
		
		return 0;
	}
	
	public static String convertPostfixToInfix​(String postfix) throws InvalidNotationFormatException
	{
		
		MyStack<String> stack = new MyStack<String>(postfix.length());

		try 
		{
			for (int i = 0; i < postfix.length(); i++) 
			{
				if (postfix.charAt(i) >= '0' && postfix.charAt(i) <= '9')
				{
					stack.push(postfix.charAt(i) + "");
				}

				if (postfix.charAt(i) == '+' || postfix.charAt(i) == '-' || postfix.charAt(i) == '*' || postfix.charAt(i) == '/') 
				{

					String second = stack.pop();
					String first = stack.pop();
					String outcome = "(" + first + postfix.charAt(i) + second + ")";
					stack.push(outcome);
				}
			}
			throw new InvalidNotationFormatException();

		} 
		
		catch (StackUnderflowException e) 
		{
			System.out.println("An underflow error");
			throw new InvalidNotationFormatException();
		} 
		
		catch (Exception e) 
		{
			System.out.println("Another type of error");
			e.printStackTrace();
		}

		return "";
	}
	
	public static String convertInfixToPostfix​(String infix) throws InvalidNotationFormatException
	{
		
		MyStack<Character> stack = new MyStack<Character>(infix.length());
		MyQueue<Character> outcome = new MyQueue<Character>(infix.length());
		String lastOutcome = "";
		
		

		try 
		{
			for (int i = 0; i < infix.length(); i++) 
			{
				if (infix.charAt(i) >= '0' && infix.charAt(i) <= '9')
				{
					outcome.enqueue(infix.charAt(i));
				}

				if (infix.charAt(i) == '(')
				{
					stack.push(infix.charAt(i));
				}

				if (infix.charAt(i) == '+' || infix.charAt(i) == '-' || infix.charAt(i) == '*' || infix.charAt(i) == '/') 
				{

					if (!stack.isEmpty()) 
					{

						if (infix.charAt(i) == '+' || infix.charAt(i) == '-') 
						{
							while (stack.top() != '(')
								outcome.enqueue(stack.pop());
						} else 
						{
							while (stack.top() == '*' || stack.top() == '/')
								outcome.enqueue(stack.pop());
						}
					}
					stack.push(infix.charAt(i));
				}

				if (infix.charAt(i) == ')') 
				{

					while (stack.top() != '(')
						outcome.enqueue(stack.pop());

					stack.pop();
				}
			}
			
			while (!stack.isEmpty())
			{
				outcome.enqueue(stack.pop());
			}
			
			int g = outcome.size();
			for (int i = 0; i < g; i++)
			{
				lastOutcome = lastOutcome + outcome.dequeue();
			}

			return lastOutcome;
		} 
		
		catch (StackUnderflowException e) 
		{
			System.out.println("An underflow error");
			throw new InvalidNotationFormatException();
		} 
		catch (Exception e) 
		{
			System.out.println("Another type of error");
			e.printStackTrace();
		}

		return "";
	}
	
}
