
public class QueueUnderflowException extends Exception {
	
	QueueUnderflowException()
	{
		super("Underflow exception");
	}

}
