import java.util.ArrayList;

public class MyQueue <T> implements QueueInterface<T>
{
	ArrayList <T> queue;
	int size;
	
	MyQueue()
	{
		size = 10;
		queue = new ArrayList<T>(10);
	}
	
	MyQueue(int size)
	{
		this.size = size;
		queue = new ArrayList<T>(this.size);
	}

	@Override
	public boolean isEmpty() 
	{
		return queue.isEmpty();
	}

	@Override
	public boolean isFull() 
	{
		if(queue.size() == size)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public T dequeue() throws QueueUnderflowException 
	{
		if(queue.isEmpty())
		{
			throw new QueueUnderflowException();
		}
		else
		{
			return queue.remove(queue.size() - 1);
		}
	}

	@Override
	public int size() 
	{
		return queue.size();
	}

	@Override
	public boolean enqueue(T e) throws QueueOverflowException 
	{
		if(isFull())
		{
			throw new QueueOverflowException();
		}
		else
		{
			ArrayList<T> copy = new ArrayList<>(queue);
			queue.clear();
			queue.add(e);
			for(int i = 0; i < copy.size(); i++)
			{
				queue.add(copy.get(i));
			}
			return true;
		}
	}
	
	public String toString()
	{
		String re = "";
		for(int i = queue.size() -1; i >= 0; i--)
		{
			re += queue.get(i);
		}
		return re;
	}
	
	@Override
	public String toString(String delimiter) 
	{
		
		String re = "";
		for(int i = queue.size() -1; i >=  1; i--)
		{
			re += queue.get(i) + delimiter;
		}
		re += queue.get(0);
		return re;
	}

	@Override
	public void fill(ArrayList<T> list) throws QueueOverflowException 
	{
		
		ArrayList <T> fill = new ArrayList<>(list);
		for(T e: fill)
		{
			enqueue(e);
		}
		
		
	}
	
	
}
