
public class StackOverflowException extends Exception {
	
	StackOverflowException()
	{
		super("Overflow exception");
	}

}
