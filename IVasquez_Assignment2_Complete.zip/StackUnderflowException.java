
public class StackUnderflowException extends Exception {
	
	StackUnderflowException()
	{
		super("Underflow Exception");
	}

}
