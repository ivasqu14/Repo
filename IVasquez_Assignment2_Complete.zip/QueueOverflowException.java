
public class QueueOverflowException extends Exception {
	
	QueueOverflowException()
	{
		super("Overflow exception");
	}

}
