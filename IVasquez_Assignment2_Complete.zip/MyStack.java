import java.util.ArrayList;

public class MyStack<T> implements StackInterface <T> 
{

	private ArrayList<T> stack;
	int size;
	
	
	MyStack()
	{
		size = 5;
		stack = new ArrayList<>(size);
	}
	
	MyStack(int size)
	{
		this.size = size;
		stack = new ArrayList<>(this.size);
	}
	
	
	@Override
	public boolean isEmpty() {
		return stack.isEmpty();
	}

	@Override
	public boolean isFull() {
		if(stack.size()>= size)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public T pop() throws StackUnderflowException {
		if(stack.isEmpty())
		{
			throw new StackUnderflowException();
		}
		return stack.remove(stack.size()-1);
		
	}

	@Override
	public T top() throws StackUnderflowException {
		if(stack.size()== 0)
		{
			throw new StackUnderflowException();
		}
		return stack.get(stack.size() - 1);
	}

	@Override
	public int size() {
		return stack.size();
	}

	@Override
	public boolean push(T e) throws StackOverflowException {
		if(this.isFull())
		{
			throw new StackOverflowException();
		}
		else
		{
			stack.add(e);
			return true;
		}
	}
	
	@Override
	public String toString()
	{
		String re = "";
		for(T e: stack)
		{
			re += e;
		}
		return re;
	}

	@Override
	public String toString(String delimiter) {
		String re = "";
		for(int i = 0; i < stack.size(); i++)
		{
			if(!(i == (stack.size() -1)))
			{
				re += stack.get(i) + delimiter;
			}
			else
			{
				re += stack.get(i);
			}
		}
		return re;
	}

	@Override
	public void fill(ArrayList<T> list) throws StackOverflowException {
		if(list.size() > size)
		{
			throw new StackOverflowException();
		}
		
		ArrayList<T> fill = new ArrayList<>(list);
		
		for(T e: fill)
		{
			stack.add(e);
		}
		
	}

}
